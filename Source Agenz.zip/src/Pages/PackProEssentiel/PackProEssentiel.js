import React from 'react';
import './PackPro.scss';

import PacksProComponent from '../../Components/PacksProEssentiel/PacksProComponent'
class  PacksProEssentiel extends React.Component {


    render() {
        return (
            <PacksProComponent />
        )
    }
}

export default PacksProEssentiel
