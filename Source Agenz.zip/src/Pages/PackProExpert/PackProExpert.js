import React from 'react';
import './PackPro.scss';

import PacksProComponent from '../../Components/PacksProExpert/PacksProComponent'
class  PacksProExpert extends React.Component {

    render() {
        return (
            <PacksProComponent />
        )
    }
}

export default PacksProExpert
