import React, { Component } from 'react'

export class PacksProTitles extends Component {
    render() {
        return (
            <>
                      
                      <div className="block">
                        <p className="text-block">
                            {/* <span>Avec Expérience Vendeurs, captez un maximum de particuliers quels que soient leurs projets de vie… Et de vente !</span> */}
                        </p>
                    </div>
                    <div className="block">
                        <h2 className="text-block">
                            <span className="font" >Comment bénéficier de l’offre Packs Pro Expert ?</span>
                        </h2>
                    </div>

            </>
        )
    }
}

export default PacksProTitles
