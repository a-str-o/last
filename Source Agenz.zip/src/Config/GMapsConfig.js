
// PROD
export const GMAPS_API_KEY ="AIzaSyCifXc9JyKKiXSAnpoOEBD7LaGNQZbX__k"


//DEV
//export const GMAPS_API_KEY ="AIzaSyDEHcOaFaclY6y09dyeCrLyPAtyidrlVrE"
